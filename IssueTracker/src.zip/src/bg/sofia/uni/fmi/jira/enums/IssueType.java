package bg.sofia.uni.fmi.jira.enums;

public enum IssueType {
	TASK, 
	BUG, 
	NEW_FEATURE;
}
