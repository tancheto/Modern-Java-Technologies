package bg.sofia.uni.fmi.jira.enums;

public enum IssueStatus {
	OPEN, 
	IN_PROGRESS, 
	RESOLVED, 
	REOPENED;
}
