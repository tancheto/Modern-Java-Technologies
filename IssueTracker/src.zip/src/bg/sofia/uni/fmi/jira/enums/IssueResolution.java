package bg.sofia.uni.fmi.jira.enums;

public enum IssueResolution {
	
	 FIXED, 
	 WONT_FIX,
	 DUPLICATE, 
	 CANNOT_REPRODUCE,
	 UNRESOLVED;
}
