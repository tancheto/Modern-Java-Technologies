package bg.sofia.uni.fmi.jira.issues.exceptions;

public class InvalidComponentException extends Exception {
	
	public InvalidComponentException(String errorMessage)
	{
		super(errorMessage);
	}

}
