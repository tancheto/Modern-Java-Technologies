package bg.sofia.uni.fmi.jira;

import java.time.LocalDateTime;

import bg.sofia.uni.fmi.jira.enums.IssuePriority;
import bg.sofia.uni.fmi.jira.enums.IssueResolution;
import bg.sofia.uni.fmi.jira.enums.IssueStatus;
import bg.sofia.uni.fmi.jira.enums.IssueType;
import bg.sofia.uni.fmi.jira.interfaces.IssueTracker;
import bg.sofia.uni.fmi.jira.issues.Issue;

public class Jira implements IssueTracker {

	private Issue[] issues;

	public Jira(Issue[] issues) {
		this.issues = issues;
	}

	public Issue[] findAll(Component component, IssueStatus status) {

		Issue[] statusIssues;
		int index = 0;

		for (Issue issue : issues) {
			if (issue.getComponent().equals(component) && status == issue.getStatus()) {
				index++;
			}
		}

		statusIssues = new Issue[index];

		index = 0;

		for (Issue issue : issues) {
			if (issue.getComponent().equals(component) && status == issue.getStatus()) {
				statusIssues[index] = issue;
				index++;
			}
		}

		return statusIssues;
	}

	public Issue[] findAll(Component component, IssuePriority priority) {

		Issue[] priorityIssues;
		int index = 0;

		for (Issue issue : issues) {
			if (issue.getComponent().equals(component) && priority == issue.getPriority()) {
				index++;
			}
		}

		priorityIssues = new Issue[index];

		index = 0;

		for (Issue issue : issues) {
			if (issue.getComponent().equals(component) && priority == issue.getPriority()) {
				priorityIssues[index] = issue;
				index++;
			}
		}

		return priorityIssues;
	}

	public Issue[] findAll(Component component, IssueType type) {

		Issue[] typeIssues;
		int index = 0;

		for (Issue issue : issues) {
			if (issue.getComponent().equals(component) && type == issue.getType()) {
				index++;
			}
		}

		typeIssues = new Issue[index];

		index = 0;

		for (Issue issue : issues) {
			if (issue.getComponent().equals(component) && type == issue.getType()) {
				typeIssues[index] = issue;
				index++;
			}
		}

		return typeIssues;
	}

	public Issue[] findAll(Component component, IssueResolution resolution) {

		Issue[] resolutionIssues;
		int index = 0;

		for (Issue issue : issues) {
			if (issue.getComponent().equals(component) && resolution == issue.getResolution()) {
				index++;
			}
		}

		resolutionIssues = new Issue[index];
		index = 0;

		for (Issue issue : issues) {
			if (issue.getComponent().equals(component) && resolution == issue.getResolution()) {
				resolutionIssues[index] = issue;
				index++;
			}
		}

		return resolutionIssues;
	}

	public Issue[] findAllIssuesCreatedBetween(LocalDateTime startTime, LocalDateTime endTime) {

		Issue[] createdBetween;
		int index = 0;

		for (Issue issue : issues) {
			if (issue.getCreatedAt().isAfter(startTime) && issue.getCreatedAt().isBefore(endTime)) {
				index++;
			}
		}

		createdBetween = new Issue[index];

		index = 0;

		for (Issue issue : issues) {
			if (issue.getCreatedAt().isAfter(startTime) && issue.getCreatedAt().isBefore(endTime)) {
				createdBetween[index] = issue;
				index++;
			}
		}

		return createdBetween;
	}

	public Issue[] findAllBefore(LocalDateTime dueTime) {

		Issue[] allBefore;
		int index = 0;

		for (Issue issue : issues) {
			if (issue.getCreatedAt().isBefore(dueTime)) {
				index++;
			}
		}

		allBefore = new Issue[index];
		index = 0;

		for (Issue issue : issues) {
			if (issue.getCreatedAt().isBefore(dueTime)) {
				allBefore[index] = issue;
				index++;
			}
		}

		return allBefore;
	}

}
