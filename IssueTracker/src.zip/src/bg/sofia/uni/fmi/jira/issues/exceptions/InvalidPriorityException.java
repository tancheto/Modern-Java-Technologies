package bg.sofia.uni.fmi.jira.issues.exceptions;

public class InvalidPriorityException extends Exception {

	public InvalidPriorityException(String errorMessage)
	{
		super(errorMessage);
	}

}
