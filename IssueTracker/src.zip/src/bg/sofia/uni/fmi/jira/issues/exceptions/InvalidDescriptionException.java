package bg.sofia.uni.fmi.jira.issues.exceptions;

public class InvalidDescriptionException extends Exception {

	public InvalidDescriptionException(String errorMessage)
	{
		super(errorMessage);
	}

}
