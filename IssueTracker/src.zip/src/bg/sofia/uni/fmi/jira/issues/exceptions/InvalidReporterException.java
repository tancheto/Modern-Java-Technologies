package bg.sofia.uni.fmi.jira.issues.exceptions;

public class InvalidReporterException extends Exception {

	public InvalidReporterException(String errorMessage)
	{
		super(errorMessage);
	}
}
